# -*- coding: utf-8 -*-

#---
# spyder
# Python 3.9.7
#---

#The data from images with low coverage of the study area will be excluded 

import pandas as pd
import os


original_data_folder = './data/water_fraction_raw'  

output_folder = './data/water_fraction' 
os.makedirs(output_folder, exist_ok=True)


special_rivers = ['borgoforte', 'parana', 'mississippi', 'chindwin','lena','yukon','mackenzie']


for filename in os.listdir(original_data_folder):
    if filename.endswith('.csv') and 'merged_water' in filename:
        river_name, a_b = filename.split('_merged_water_')
        a, b = a_b.split('_')[0], a_b.split('_')[1].split('.')[0]
        

        file_path = os.path.join(original_data_folder, filename)
        data = pd.read_csv(file_path)
        

        if river_name in special_rivers:

            min_pixel_count = data['totalPixelCount'].min()

            data = data[data['totalPixelCount'] != min_pixel_count]
        

        output_filename = f"{river_name}_{a}_{b}.csv"
        output_file_path = os.path.join(output_folder, output_filename)
        data[['Time', 'water_fraction', 'Q']].to_csv(output_file_path, index=False)